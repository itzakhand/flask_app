from flask import Flask, render_template

app = Flask(__name__)


@app.route('/')
def home():  # put application's code here
    return render_template('index.html')

@app.route('/about')
def about():  # put application's code here
    return render_template('about.html')

@app.route('/service')
def service():  # put application's code here
    return render_template('service.html')

@app.route('/portfolio')
def portfolio():  # put application's code here
    return render_template('project.html')

@app.route('/contact')
def constact():  # put application's code here
    return render_template('contact.html')


if __name__ == '__main__':
    app.run(debug=True)
